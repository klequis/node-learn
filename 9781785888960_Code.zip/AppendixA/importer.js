let myClass = require('./exporter.js');

console.log(myClass.foo)
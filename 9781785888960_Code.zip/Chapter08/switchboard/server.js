'use strict';

require('./router');
'use strict';

require('dotenv').config();
require('./router');
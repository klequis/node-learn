console.log(new Error("My Error Message").stack);

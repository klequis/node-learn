function (a, b) {
    // Grab any arguments after a & b and convert to proper Array
    let args = Array.prototype.slice.call(arguments, f.length);
}

function (a, b, ...args) {
    // #args is already an Array!
}
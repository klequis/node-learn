setTimeout(() => {
	let dummyVar = 123;
	debugger;
	console.log('world');
}, 1000);
console.log('hello');

require('seneca')().use('mesh', {
    base: true
});
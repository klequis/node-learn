const calculator = require('./build/Release/calculator');

module.exports = calculator;
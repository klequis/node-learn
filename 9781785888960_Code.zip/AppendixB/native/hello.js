const {sayHello} = require('./hello_module');
console.log(sayHello());
